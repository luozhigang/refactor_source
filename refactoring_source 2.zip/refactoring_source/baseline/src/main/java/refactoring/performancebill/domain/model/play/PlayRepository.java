package refactoring.performancebill.domain.model.play;

public interface PlayRepository {
    Play findById(String playId);
}
