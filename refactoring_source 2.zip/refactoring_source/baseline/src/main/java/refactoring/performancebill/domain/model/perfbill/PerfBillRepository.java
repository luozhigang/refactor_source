package refactoring.performancebill.domain.model.perfbill;

public interface PerfBillRepository {
    PerfBill save(PerfBill bill);
}
