package refactoring.performancebill.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import refactoring.performancebill.domain.model.perfbill.PerfBill;
import refactoring.performancebill.domain.model.perfbill.PerfBillItem;
import refactoring.performancebill.domain.model.perfbill.PerfBillRepository;
import refactoring.performancebill.domain.model.perfsummary.Perf;
import refactoring.performancebill.domain.model.perfsummary.PerfSummary;
import refactoring.performancebill.domain.model.play.Play;
import refactoring.performancebill.domain.model.play.PlayRepository;
import refactoring.performancebill.infrastructure.enums.PlayType;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class PerfBillService {
    @Autowired
    PerfBillRepository perfBillRepository;

    @Autowired
    PlayRepository playRepository;

    @Transactional
    public PerfBill createBill(@RequestBody PerfSummary perfSummary) {
        PerfBill bill;
        bill = new PerfBill(perfSummary.getCustomer());

        bill.setItems(buildPerfBillItems(perfSummary));
        bill.setTotalAmount(calTotalAmount(perfSummary));
        bill.setVolumeCredits(calTotalVolumeCredits(perfSummary));

        return perfBillRepository.save(bill);
    }

    private int calTotalVolumeCredits(PerfSummary perfSummary){
        int volumeCredits = 0;
        for (Perf perf : perfSummary.getPerfs()) {
            Play play = playRepository.findById(perf.getPlayId());

            Calculator calculator = buildCalculator(play);
            int thisCredits = calculator.calCredits(perf, play);
            volumeCredits += thisCredits;
        }
        return volumeCredits;
    }

    private int calTotalAmount(PerfSummary perfSummary){
        int totalAmount = 0;
        for (Perf perf : perfSummary.getPerfs()) {
            Play play = playRepository.findById(perf.getPlayId());

            Calculator calculator = buildCalculator(play);
            int thisAmount = calculator.calAmount(perf, play);
            totalAmount += thisAmount;
        }
        return totalAmount;
    }

    private List<PerfBillItem> buildPerfBillItems(@RequestBody PerfSummary perfSummary) {
        List<PerfBillItem> result = new ArrayList<>();

        for (Perf perf : perfSummary.getPerfs()) {
            Play play = playRepository.findById(perf.getPlayId());

            Calculator calculator = buildCalculator(play);
            int thisAmount = calculator.calAmount(perf, play);

            result.add(new PerfBillItem(play.getName(), thisAmount, perf.getAudience()));
        }
        return result;
    }

    private Calculator buildCalculator(Play play) {
        Calculator calculator;
        if (PlayType.悲剧.getCode().equals(play.getType())) {
            calculator = new TragedyCalculator();
        } else {
            calculator = new ComedyCalculator();
        }
        return calculator;
    }

}
