package refactoring.performancebill.application;

import refactoring.performancebill.domain.model.perfsummary.Perf;
import refactoring.performancebill.domain.model.play.Play;

public class TragedyCalculator extends Calculator {

    private static final int START_EXPENSE = 40000;
    private static final int OVER_START_AUDIENCE = 30;
    private static final int START_EXTRAL_BAISC_EXPNENSE = 1000;
    private static final int START_CREDITS_AUDIENCE = 30;

    @Override
    public int calAmount(Perf perf, Play play) {
        int thisAmount;
        thisAmount = START_EXPENSE;
        if (perf.getAudience() > OVER_START_AUDIENCE) {
            thisAmount += START_EXTRAL_BAISC_EXPNENSE * (perf.getAudience() - OVER_START_AUDIENCE);
        }
        return thisAmount;
    }

    @Override
    public int calCredits(Perf perf, Play play) {
        //计算观众量积分
        int thisCredits = 0;
        thisCredits = Math.max(perf.getAudience() - START_CREDITS_AUDIENCE, 0);
        return thisCredits;
    }
}
