package refactoring.performancebill.infrastructure.enums;

public enum PlayType {

    悲剧("tragedy");

    private String code;

    PlayType(String code){
        this.code = code;
    }

    public String getCode(){
        return this.code;
    }
}
